var $vas = jQuery.noConflict();
(function( $vas ) {
    'use strict';

    $var(function() {
        

        
    });

 
})( jQuery );
