var $var = jQuery.noConflict();
(function( $var ) {
    'use strict';

    $var(function() {
        

        $var('.plps_swatch_size_select').select2();
    });

 
})( jQuery );


