var $saz = jQuery.noConflict();
(function( $saz ) {
    'use strict';

    $saz(function() {
        
        $saz("li#toplevel_page_woomatrix a.toplevel_page_woomatrix").removeAttr("href");

    });

 
})( jQuery );