        <?php $advancedsettings=$this->advanced_settings;  ?> 
         
		<table class="table">
		     
			<tr>
               <td width="50%"><label><?php  echo esc_html__('Enable tooltip on swatches','wcva'); ?></label> <br />
			   </td>
               <td width="50%">
               <input type="checkbox" class="productcheckbox" name="<?php  echo esc_html__($this->wcva_notices_settings_page); ?>[tooltip]" value="yes" <?php if (isset($advancedsettings['tooltip']) && ($advancedsettings['tooltip'] == "yes")) { echo 'checked'; } ?>>
               </td>
            </tr>


            <tr>
               <td width="50%"><label><?php echo esc_html__('Swatch size','wcva'); ?></label> <br />
			   </td>
               <td width="50%">
                 <select class="wcva_swatch_size_select" name="<?php  echo esc_html__($this->wcva_notices_settings_page); ?>[swatch_size]">
	               <option value="small" <?php if (isset($advancedsettings['swatch_size']) && ($advancedsettings['swatch_size'] == "small")) { echo 'selected'; } ?>><?php echo esc_html__('Small','wcva'); ?> (32px * 32px)</option>
		           <option value="extrasmall" <?php if (isset($advancedsettings['swatch_size']) && ($advancedsettings['swatch_size'] == "extrasmall")) { echo 'selected'; } ?>><?php echo esc_html__('Extra Small','wcva'); ?> Small (22px * 22px)</option>
		           <option value="medium" <?php if (isset($advancedsettings['swatch_size']) && ($advancedsettings['swatch_size'] == "medium")) { echo 'selected'; } ?>><?php echo esc_html__('Middle','wcva'); ?> (40px * 40px)</option>
		           <option value="big" <?php if (isset($advancedsettings['swatch_size']) && ($advancedsettings['swatch_size'] == "big")) { echo 'selected'; } ?>><?php echo esc_html__('Big','wcva'); ?> (60px * 60px)</option>
		           <option value="extrabig" <?php if (isset($advancedsettings['swatch_size']) && ($advancedsettings['swatch_size'] == "extrabig")) { echo 'selected'; } ?>><?php echo esc_html__('Extra Big','wcva'); ?> (90px * 90px)</option>
			       
		          </select>
               </td>
            </tr>

        </table>