<?php
if (!class_exists('wcva_add_settings_page_class')) {

class wcva_add_settings_page_class {
	
	

	private $wcva_notices_options_key   = 'wcva_plugin_options';
	private $wcva_notices_settings_page = 'wcva_advanced_settings';
	private $wcva_plugin_settings_tab   = array();
	
	
	public function __construct() {
		add_action( 'init', array( $this, 'load_settings' ) );
		add_action( 'admin_init', array( $this, 'wcva_register_settings_settings' ) );
		add_action( 'admin_menu', array( $this, 'add_admin_menus' ) ,100);
		add_action( 'admin_enqueue_scripts', array($this, 'wcva_register_admin_scripts'));
		add_action( 'admin_enqueue_scripts', array($this, 'wcva_load_admin_menu_style'));
        add_action( 'wp_ajax_wcvagetajaxlinkedproductslist', array( $this, 'wcva_get_linked_ajax_products_list' ) );

		
	}
	
	
	public function load_settings() {
		
		$this->advanced_settings = (array) get_option( $this->wcva_notices_settings_page );
		
	}

	public function wcva_load_admin_menu_style() {

	    wp_enqueue_style( 'woomatrix_admin_menu_css', ''.wcva_PLUGIN_URL.'assets/css/admin_menu.css' );
	    wp_enqueue_script( 'woomatrix_admin_menu_js', ''.wcva_PLUGIN_URL.'assets/js/admin_menu.js' );


	}


	public function wcva_get_posts_ajax_callback(){
 
	
	  $return          = array();
	  
      $post_type_array = array('product','product_variant');
	  // you can use WP_Query, query_posts() or get_posts() here - it doesn't matter
	  $search_results  = new WP_Query( array( 
		's'                   => sanitize_text_field($_GET['q']), // the search query
		'post_status'         => 'publish', // if you don't want drafts to be returned
		'ignore_sticky_posts' => 1,
		'post_type'           => $post_type_array
	  ) );
	  

	
	  if( $search_results->have_posts() ) :
		while( $search_results->have_posts() ) : $search_results->the_post();

		    $product_type = WC_Product_Factory::get_product_type($search_results->post->ID);	
			// shorten the title a little
			

			
				 $finaltitle='#'. $search_results->post->ID.'- '.$search_results->post->post_title.'';
				 $return[] = array( $search_results->post->ID, $finaltitle );
			
			
			  

			 // array( Post ID, Post Title )
		endwhile;
	  endif;
	   echo json_encode( $return );
	  die;
    }
	
	/*
	 * registers admin scripts via admin enqueue scripts
	 */
	public function wcva_register_admin_scripts($hook) {
	    global $general_wcvasettings_page;
			
		if ( $hook == $general_wcvasettings_page ) {

 

		    wp_enqueue_script( 'select2', ''.wcva_PLUGIN_URL.'assets/js/select2.js' );
	        wp_enqueue_script( 'wcvaadmin', ''.wcva_PLUGIN_URL.'assets/js/admin.js' );
		
         
	
		    wp_enqueue_style( 'select2',''.wcva_PLUGIN_URL.'assets/css/select2.css');
		    wp_enqueue_style( 'wcvaadmin', ''.wcva_PLUGIN_URL.'assets/css/admin.css' );


		 
		    $wcva_js_array = array();

            wp_localize_script( 'wcvaadmin', 'wcvaadmin', $wcva_js_array );

        }
	}
	
	

	
	
	public function wcva_register_settings_settings() {

		$this->wcva_plugin_settings_tab[$this->wcva_notices_settings_page] = esc_html__( 'Settings' ,'wcva');

		

		register_setting( $this->wcva_notices_settings_page, $this->wcva_notices_settings_page );

		add_settings_section( 'wcva_advance_section', '', '', $this->wcva_notices_settings_page );

		add_settings_field( 'advanced_option', '', array( $this, 'linked_product_swatches_settings' ), $this->wcva_notices_settings_page, 'wcva_advance_section' );

	}
	

	

	

	/*
     * Linked product swatached settings
     * includes form field from forms folder
     */
	
	public function linked_product_swatches_settings() { 

	   include ('forms/settings_form.php');
		   
	}
	
	
	/*
     * Adds Admin Menu "cart notices"
     * global $general_wcvasettings_page is used to include page specific scripts
     */

	public function add_admin_menus() {
	    global $general_wcvasettings_page;
        
        add_menu_page(
          __( 'woomatrix', 'wcva' ),
         'WooMatrix',
         'manage_woocommerce',
         'woomatrix',
         array($this,'plugin_options_page'),
         ''.wcva_PLUGIN_URL.'assets/images/icon.png',
         70
        );
	    

        $general_wcvasettings_page = add_submenu_page( 'woomatrix', wcva_PLUGIN_name , wcva_PLUGIN_name , 'manage_woocommerce', esc_html__($this->wcva_notices_settings_page), array($this, 'plugin_options_page'));


	         
	}




	public function plugin_options_page() {
		$tab = isset( $_GET['tab'] ) ? $_GET['tab'] : esc_html__($this->wcva_notices_settings_page);
		?>
		<div class="wrap">
		   <?php $this->wcva_options_tab_wrap(); ?>
			<form method="post" action="options.php">
				<?php wp_nonce_field( 'update-options' ); ?>
				<?php settings_fields( $tab ); ?>
				<?php do_settings_sections( $tab ); ?>
				<center><input type="submit" name="submit" id="submit" class="btn btn-success" value="<?php echo esc_html__( 'Save Changes' ,'wcva'); ?>"></center>
				
			</form>
		</div>
		<?php
	}


	
	public function wcva_options_tab_wrap() {

		$current_tab = isset( $_GET['tab'] ) ? $_GET['tab'] : esc_html__($this->wcva_notices_settings_page);

        echo '<h2 class="nav-tab-wrapper">';

		foreach ( $this->wcva_plugin_settings_tab as $tab_key => $tab_caption ) {

			$active = $current_tab == $tab_key ? 'nav-tab-active' : '';

			echo '<a class="nav-tab ' . esc_html__($active) . '" href="?page=' . esc_html__($this->wcva_notices_settings_page) . '&tab=' . esc_html__($tab_key) . '">' . esc_html__($tab_caption) . '</a>';	

		}

		echo '</h2>';

	}

}
}


new wcva_add_settings_page_class();
?>